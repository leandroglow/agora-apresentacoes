/**
 * Public API — the two entry points consumed by the rest of the application.
 *
 * The conversion pipeline for both formats follows the same high-level steps:
 * 1. Parse the file header to determine logical bounds and canvas dimensions.
 * 2. Create an in-memory canvas (OffscreenCanvas preferred, HTMLCanvasElement fallback).
 * 3. Replay every metafile record onto the canvas context in order.
 * 4. Resolve "deferred images" — bitmap / embedded-metafile draws that require
 *    async image decoding (via {@link createImageBitmap}).
 * 5. Export the canvas contents as a `data:image/png;base64,…` URL.
 *
 * @module emf-converter
 */

import { createCanvas, exportCanvasToPngDataUrl, DEFAULT_DPI_SCALE } from './emf-canvas-helpers';
import { parseEmfHeader, getRenderableEmfBounds, parseWmfHeader } from './emf-header-parser';
import { emfLog, emfWarn } from './emf-logging';
import { replayEmfRecords } from './emf-record-replay';
import type { DeferredImageDraw } from './emf-types';
import { replayWmfRecords } from './wmf-replay';

/**
 * Configuration options for EMF/WMF conversion.
 */
export interface EmfConvertOptions {
	/** Maximum output width in pixels. */
	maxWidth?: number;
	/** Maximum output height in pixels. */
	maxHeight?: number;
	/**
	 * DPI scale factor for higher-resolution output.
	 * Default is 2 (HiDPI). Set to 1 for 1:1 pixel mapping.
	 * Values above 4 are clamped to 4 to prevent excessive memory usage.
	 */
	dpiScale?: number;
	/**
	 * Hard cap on the output canvas width/height in pixels. Guards against
	 * pathological metafiles. Defaults to {@link MAX_CANVAS_DIMENSION} (8192).
	 */
	maxCanvasDimension?: number;
	/**
	 * Maximum number of records processed per stream before replay stops.
	 * Defaults to 200,000 for GDI/WMF and 500,000 for the finer-grained EMF+
	 * stream. Supplying a value overrides both with the same cap.
	 */
	maxRecords?: number;
	/**
	 * Optional map from a (case-insensitive) Windows face name to a CSS font
	 * family available in the rendering environment, e.g. `{ calibri: 'Carlito',
	 * 'ms shell dlg': 'Tahoma' }`. Applied to GDI, WMF, and EMF+ text.
	 */
	fontFamilyMap?: Record<string, string>;
}

// ---------------------------------------------------------------------------
// Deferred-image post-processing
// ---------------------------------------------------------------------------

/**
 * Processes images whose drawing was deferred during the synchronous record
 * replay pass. Each entry may be a raster image (PNG/BMP bytes) or an
 * embedded metafile that must be recursively converted before it can be drawn.
 *
 * The canvas transform is set per-image so the bitmap lands at the correct
 * position, then reset to identity when all images have been drawn.
 *
 * @param ctx            - The 2D rendering context of the output canvas.
 * @param deferredImages - The list of deferred image-draw descriptors
 *                         accumulated during GDI / EMF+ record replay.
 */
const MAX_METAFILE_RECURSION = 3;

async function processDeferredImages(
	ctx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D,
	deferredImages: DeferredImageDraw[],
	recursionDepth: number = 0,
): Promise<void> {
	emfLog(
		`processDeferredImages: processing ${deferredImages.length} deferred images (recursionDepth=${recursionDepth})...`,
	);

	for (let idx = 0; idx < deferredImages.length; idx++) {
		const img = deferredImages[idx];
		emfLog(
			`  Deferred image [${idx}]: isMetafile=${img.isMetafile}, dataLen=${img.imageData.byteLength}, ` +
				`dest=(${img.dx.toFixed(1)},${img.dy.toFixed(1)},${img.dw.toFixed(1)},${img.dh.toFixed(1)}), ` +
				`transform=[${img.transform.map((v) => v.toFixed(3)).join(',')}]`,
		);
		try {
			// Copy to a plain ArrayBuffer — SharedArrayBuffer is not accepted
			// as a BlobPart by the Blob constructor in TypeScript 5.x strict mode.
			const plainBuffer = new ArrayBuffer(img.imageData.byteLength);
			const dstBytes = new Uint8Array(plainBuffer);
			dstBytes.set(new Uint8Array(img.imageData));

			// Restore the affine transform that was active when the image draw was
			// originally encountered, so the bitmap is placed correctly on canvas.
			ctx.setTransform(
				img.transform[0],
				img.transform[1],
				img.transform[2],
				img.transform[3],
				img.transform[4],
				img.transform[5],
			);

			if (img.isMetafile) {
				// Embedded metafiles must be recursively converted to a raster image
				// before they can be drawn — try EMF first, then fall back to WMF.
				if (recursionDepth >= MAX_METAFILE_RECURSION) {
					emfWarn(
						`  Deferred image [${idx}]: skipping embedded metafile — recursion depth ${recursionDepth} >= ${MAX_METAFILE_RECURSION}`,
					);
					continue;
				}
				emfLog(`  Deferred image [${idx}]: recursively converting embedded metafile...`);
				const metafileDataUrl =
					(await convertEmfToDataUrl(plainBuffer, undefined, recursionDepth + 1)) ??
					(await convertWmfToDataUrl(plainBuffer, undefined, recursionDepth + 1));
				if (metafileDataUrl) {
					// Decode the data-URL back to raw bytes so we can build a Blob
					// and hand it to createImageBitmap for drawing.
					emfLog(
						`  Deferred image [${idx}]: metafile converted, dataUrl length=${metafileDataUrl.length}`,
					);
					const byteString = atob(metafileDataUrl.split(',')[1]);
					const mimeMatch = metafileDataUrl.match(/data:([^;]+)/);
					const mime = mimeMatch ? mimeMatch[1] : 'image/png';
					const ab = new ArrayBuffer(byteString.length);
					const ia = new Uint8Array(ab);
					for (let i = 0; i < byteString.length; i++) {
						ia[i] = byteString.charCodeAt(i);
					}
					const metaBlob = new Blob([ab], { type: mime });
					emfLog(
						`  Deferred image [${idx}]: creating ImageBitmap from ${metaBlob.size} byte blob (${mime})...`,
					);
					const bitmap = await createImageBitmap(metaBlob);
					emfLog(`  Deferred image [${idx}]: ImageBitmap created ${bitmap.width}×${bitmap.height}`);
					ctx.drawImage(bitmap, img.dx, img.dy, img.dw, img.dh);
					bitmap.close();
				} else {
					emfWarn(`  Deferred image [${idx}]: metafile conversion returned null`);
				}
			} else {
				emfLog(
					`  Deferred image [${idx}]: creating ImageBitmap from ${plainBuffer.byteLength} byte blob...`,
				);
				const blob = new Blob([plainBuffer]);
				const bitmap = await createImageBitmap(blob);
				emfLog(`  Deferred image [${idx}]: ImageBitmap created ${bitmap.width}×${bitmap.height}`);
				ctx.drawImage(bitmap, img.dx, img.dy, img.dw, img.dh);
				bitmap.close();
			}
		} catch (imgErr) {
			const errMsg = imgErr instanceof Error ? imgErr.message : String(imgErr);
			emfWarn(`  Deferred image [${idx}]: DRAW FAILED: ${errMsg}`);
			console.warn(
				'[emf-converter] Deferred image draw failed:',
				imgErr instanceof Error ? imgErr.message : imgErr,
				`(isMetafile=${img.isMetafile}, dataLen=${img.imageData.byteLength})`,
			);
		}
	}
	// Reset to identity so subsequent callers start with a clean transform.
	ctx.setTransform(1, 0, 0, 1, 0, 0);
}

// ---------------------------------------------------------------------------
// convertEmfToDataUrl
// ---------------------------------------------------------------------------

/**
 * Converts an EMF (Enhanced Metafile) binary buffer to a PNG data-URL string
 * by parsing the EMF header, iterating over all EMR records, and replaying
 * them onto an in-memory canvas. Embedded EMF+ (GDI+) records found inside
 * EMR_COMMENT payloads are handled transparently.
 *
 * The canvas is rendered at a configurable DPI scale (default 2x) to produce
 * sharper output when displayed at CSS logical-pixel sizes. This is important
 * for presentations viewed on HiDPI/Retina displays.
 *
 * Returns `null` when:
 * - The buffer does not begin with a valid EMR_HEADER record.
 * - The logical bounds are zero-sized or negative.
 * - No canvas API is available (e.g. headless test environment).
 *
 * @param buffer  - The raw EMF file bytes.
 * @param options - Optional {@link EmfConvertOptions} controlling output size,
 *   DPI scale, record limits, and font mapping.
 * @returns A `data:image/png;base64,…` string, or `null` on failure.
 */
export async function convertEmfToDataUrl(
	buffer: ArrayBuffer,
	options?: EmfConvertOptions,
	recursionDepth: number = 0,
): Promise<string | null> {
	if (recursionDepth > MAX_METAFILE_RECURSION) {
		emfWarn(
			`convertEmfToDataUrl: recursion depth ${recursionDepth} exceeds limit ${MAX_METAFILE_RECURSION} — refusing to convert`,
		);
		return null;
	}
	const opts = options ?? {};
	const dpiScale = opts.dpiScale ?? DEFAULT_DPI_SCALE;
	const effectiveMaxWidth = opts.maxWidth;
	const effectiveMaxHeight = opts.maxHeight;
	const replayOptions = {
		maxRecords: opts.maxRecords,
		maxRecordsEmfPlus: opts.maxRecords,
		fontFamilyMap: opts.fontFamilyMap,
	};

	try {
		emfLog('=== convertEmfToDataUrl START ===');
		emfLog(
			`Input buffer: ${buffer.byteLength} bytes, maxWidth=${effectiveMaxWidth}, maxHeight=${effectiveMaxHeight}, dpiScale=${dpiScale}`,
		);

		if (buffer.byteLength >= 16) {
			const hdrBytes = new Uint8Array(buffer, 0, 16);
			emfLog(
				`First 16 bytes: [${Array.from(hdrBytes)
					.map((b) => b.toString(16).padStart(2, '0'))
					.join(' ')}]`,
			);
		}

		const view = new DataView(buffer);
		const header = parseEmfHeader(view);
		if (!header) {
			emfLog('convertEmfToDataUrl: parseEmfHeader returned null — returning null');
			return null;
		}
		const renderBounds = getRenderableEmfBounds(header);
		if (!renderBounds) {
			emfLog('convertEmfToDataUrl: getRenderableEmfBounds returned null — returning null');
			return null;
		}

		const logicalW = renderBounds.right - renderBounds.left;
		const logicalH = renderBounds.bottom - renderBounds.top;
		emfLog(`convertEmfToDataUrl: logicalSize=${logicalW}×${logicalH}`);

		const setup = createCanvas(
			logicalW,
			logicalH,
			effectiveMaxWidth,
			effectiveMaxHeight,
			dpiScale,
			opts.maxCanvasDimension,
		);
		if (!setup) {
			emfLog('convertEmfToDataUrl: createCanvas returned null — returning null');
			return null;
		}

		const { canvas, ctx } = setup;
		emfLog(
			`convertEmfToDataUrl: canvas created ${canvas.width}×${canvas.height} (dpiScale=${dpiScale})`,
		);

		ctx.save();

		emfLog('convertEmfToDataUrl: starting replayEmfRecords...');
		const deferredImages = replayEmfRecords(
			view,
			ctx,
			renderBounds,
			canvas.width,
			canvas.height,
			dpiScale,
			replayOptions,
		);
		emfLog(
			`convertEmfToDataUrl: replayEmfRecords returned ${deferredImages.length} deferred images`,
		);

		// Restore the canvas state saved before replay — this clears any
		// clipping regions that GDI record handlers may have installed.
		ctx.restore();

		await processDeferredImages(ctx, deferredImages);

		emfLog('convertEmfToDataUrl: exporting canvas to PNG data URL...');
		const result = await exportCanvasToPngDataUrl(canvas);
		if (result) {
			emfLog(`convertEmfToDataUrl: SUCCESS — data URL length=${result.length}`);
		} else {
			emfWarn('convertEmfToDataUrl: exportCanvasToPngDataUrl returned null');
		}
		emfLog('=== convertEmfToDataUrl END ===');
		return result;
	} catch (err) {
		emfWarn('convertEmfToDataUrl: EXCEPTION:', err instanceof Error ? err.message : err);
		console.warn('[pptx-editor] EMF conversion failed:', err instanceof Error ? err.message : err);
		return null;
	}
}

// ---------------------------------------------------------------------------
// convertWmfToDataUrl
// ---------------------------------------------------------------------------

/**
 * Converts a WMF (Windows Metafile) binary buffer to a PNG data-URL string.
 *
 * WMF is the older 16-bit metafile format with simpler record types than EMF.
 * This function parses the optional Aldus placeable header, the WMF header,
 * and then replays all META_* records onto a canvas.
 *
 * The canvas is rendered at a configurable DPI scale (default 2x) for
 * sharper output on HiDPI displays.
 *
 * Returns `null` when:
 * - The header cannot be parsed or reports invalid dimensions.
 * - No canvas API is available.
 *
 * @param buffer  - The raw WMF file bytes.
 * @param options - Optional {@link EmfConvertOptions} controlling output size,
 *   DPI scale, record limits, and font mapping.
 * @returns A `data:image/png;base64,…` string, or `null` on failure.
 */
export async function convertWmfToDataUrl(
	buffer: ArrayBuffer,
	options?: EmfConvertOptions,
	recursionDepth: number = 0,
): Promise<string | null> {
	if (recursionDepth > MAX_METAFILE_RECURSION) {
		emfWarn(
			`convertWmfToDataUrl: recursion depth ${recursionDepth} exceeds limit ${MAX_METAFILE_RECURSION} — refusing to convert`,
		);
		return null;
	}
	const opts = options ?? {};
	const dpiScale = opts.dpiScale ?? DEFAULT_DPI_SCALE;
	const effectiveMaxWidth = opts.maxWidth;
	const effectiveMaxHeight = opts.maxHeight;
	const replayOptions = {
		maxRecords: opts.maxRecords,
		fontFamilyMap: opts.fontFamilyMap,
	};

	try {
		emfLog(
			'=== convertWmfToDataUrl START ===',
			`buffer=${buffer.byteLength} bytes, dpiScale=${dpiScale}`,
		);
		const view = new DataView(buffer);
		const header = parseWmfHeader(view);
		if (!header) {
			emfLog('convertWmfToDataUrl: parseWmfHeader returned null');
			return null;
		}

		const logicalW = header.boundsRight - header.boundsLeft;
		const logicalH = header.boundsBottom - header.boundsTop;
		emfLog(`convertWmfToDataUrl: logicalSize=${logicalW}×${logicalH}`);

		if (logicalW <= 0 || logicalH <= 0) {
			emfLog('convertWmfToDataUrl: invalid dimensions — returning null');
			return null;
		}

		const setup = createCanvas(
			logicalW,
			logicalH,
			effectiveMaxWidth,
			effectiveMaxHeight,
			dpiScale,
			opts.maxCanvasDimension,
		);
		if (!setup) {
			return null;
		}

		const { canvas, ctx } = setup;

		ctx.save();
		replayWmfRecords(view, ctx, header, canvas.width, canvas.height, replayOptions);
		ctx.restore();

		const result = await exportCanvasToPngDataUrl(canvas);
		emfLog(`convertWmfToDataUrl: result=${result ? `dataUrl len=${result.length}` : 'null'}`);
		emfLog('=== convertWmfToDataUrl END ===');
		return result;
	} catch (err) {
		emfWarn('convertWmfToDataUrl: EXCEPTION:', err instanceof Error ? err.message : err);
		console.warn('[pptx-editor] WMF conversion failed:', err instanceof Error ? err.message : err);
		return null;
	}
}
