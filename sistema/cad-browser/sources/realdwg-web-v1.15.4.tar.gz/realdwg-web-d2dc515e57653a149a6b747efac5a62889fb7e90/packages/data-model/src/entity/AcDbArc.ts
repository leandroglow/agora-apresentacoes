import {
  AcGeCircArc3d,
  acgeGetOcsAngle,
  acgeGetOcsReferenceVector,
  acgeGetOcsReferenceVectorInto,
  AcGeIntersectPrimitive,
  AcGeMathUtil,
  AcGeMatrix3d,
  AcGePoint3d,
  AcGePoint3dLike,
  acgeTransformOcsPointToWcsInto,
  acgeTransformWcsPointToOcs,
  AcGeVector3d,
  AcGeVector3dLike} from '@mlightcad/geometry-engine'
import { AcGiRenderer } from '@mlightcad/graphic-interface'

import { AcDbDxfFiler } from '../base/AcDbDxfFiler'
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode'
import { AcDbCurve } from './AcDbCurve'
import { AcDbEntityProperties } from './AcDbEntityProperties'
import { acdbForEachGripIndex } from './AcDbGripHelpers'
import { acdbPickNearestOsnapPoint } from './AcDbOsnapHelpers'

/** Reused across dxfIn to avoid per-entity temporaries (parse is sequential). */
const _dxfInNormal = /*@__PURE__*/ new AcGeVector3d()
const _dxfInRefVec = /*@__PURE__*/ new AcGeVector3d()
const _dxfInPoint = /*@__PURE__*/ new AcGePoint3d()

/**
 * Represents an arc entity in AutoCAD.
 *
 * An arc is a 2D geometric object defined by its center point, radius, start angle,
 * and end angle. Arcs are portions of circles that can be used to create curved
 * line segments in drawings. The arc is always drawn in the plane defined by its normal vector.
 *
 * @example
 * ```typescript
 * // Create a 90-degree arc from 0 to π/2 radians
 * const arc = new AcDbArc(
 *   new AcGePoint3d(0, 0, 0),
 *   10,
 *   0,
 *   Math.PI / 2
 * );
 *
 * // Access arc properties
 * console.log(`Center: ${arc.center}`);
 * console.log(`Radius: ${arc.radius}`);
 * console.log(`Start angle: ${arc.startAngle}`);
 * console.log(`End angle: ${arc.endAngle}`);
 * ```
 */
export class AcDbArc extends AcDbCurve {
  /** The entity type name */
  static override typeName: string = 'Arc'

  override get dxfTypeName() {
    return 'ARC'
  }

  /** Backing for the lazily materialized geometric circular arc object. */
  private _geoData: AcGeCircArc3d | null = null
  /** Thickness along the normal (DXF group 39) */
  private _thickness = 0

  /**
   * The underlying geometric circular arc object. Materialized lazily so that
   * factory-created entities (dxfIn path) never allocate default geometry.
   */
  private get _geo(): AcGeCircArc3d {
    if (this._geoData == null) {
      this._geoData = new AcGeCircArc3d(
        new AcGePoint3d(),
        1,
        0,
        Math.PI / 2,
        AcGeVector3d.Z_AXIS,
        AcGeVector3d.X_AXIS
      )
    }
    return this._geoData
  }

  private set _geo(value: AcGeCircArc3d) {
    this._geoData = value
  }

  /**
   * Creates a new arc entity.
   *
   * This constructor creates an arc using the specified center point, radius,
   * start angle, and end angle. The center point must be in World Coordinate
   * System (WCS) coordinates. Angles are specified in radians.
   *
   * @param center - The center point of the arc in WCS coordinates
   * @param radius - The radius of the arc (must be positive)
   * @param startAngle - The starting angle in radians (0 to 2π)
   * @param endAngle - The ending angle in radians (0 to 2π)
   * @param normal - The normal vector defining the plane of the circle (defaults to Z-axis)
   *
   * @example
   * ```typescript
   * // Create a quarter circle arc (0 to 90 degrees)
   * const quarterArc = new AcDbArc(
   *   new AcGePoint3d(0, 0, 0),
   *   15,
   *   0,
   *   Math.PI / 2
   * );
   *
   * // Create a semicircle arc (0 to 180 degrees)
   * const semicircle = new AcDbArc(
   *   new AcGePoint3d(10, 20, 0),
   *   25,
   *   0,
   *   Math.PI
   * );
   * ```
   */
  constructor()
  constructor(
    center: AcGePoint3dLike,
    radius: number,
    startAngle: number,
    endAngle: number,
    normal?: AcGeVector3dLike
  )
  constructor(
    center?: AcGePoint3dLike,
    radius?: number,
    startAngle?: number,
    endAngle?: number,
    normal: AcGeVector3dLike = AcGeVector3d.Z_AXIS
  ) {
    super()
    if (
      center !== undefined &&
      radius !== undefined &&
      startAngle !== undefined &&
      endAngle !== undefined
    ) {
      const refVec = acgeGetOcsReferenceVector(normal)
      this._geo = new AcGeCircArc3d(
        center,
        radius,
        startAngle,
        endAngle,
        normal,
        refVec
      )
    }
  }

  /**
   * Gets the center point of this arc.
   *
   * @returns The center point as a 3D point
   *
   * @example
   * ```typescript
   * const centerPoint = arc.center;
   * console.log(`Arc center: ${centerPoint.x}, ${centerPoint.y}, ${centerPoint.z}`);
   * ```
   */
  get center(): AcGePoint3d {
    return this._geo.center
  }

  /**
   * Sets the center point of this arc.
   *
   * @param value - The new center point
   *
   * @example
   * ```typescript
   * arc.center = new AcGePoint3d(5, 5, 0);
   * ```
   */
  set center(value: AcGePoint3dLike) {
    this._geo.center = value
  }

  /**
   * Gets the radius of this arc.
   *
   * @returns The radius value
   *
   * @example
   * ```typescript
   * const radius = arc.radius;
   * console.log(`Arc radius: ${radius}`);
   * ```
   */
  get radius(): number {
    return this._geo.radius
  }

  /**
   * Sets the radius of this arc.
   *
   * @param value - The new radius value (must be positive)
   *
   * @example
   * ```typescript
   * arc.radius = 25;
   * ```
   */
  set radius(value: number) {
    this._geo.radius = value
  }

  /**
   * Gets the start angle of this arc.
   *
   * @returns The start angle in radians
   *
   * @example
   * ```typescript
   * const startAngle = arc.startAngle;
   * console.log(`Arc start angle: ${startAngle} radians (${startAngle * 180 / Math.PI} degrees)`);
   * ```
   */
  get startAngle(): number {
    return this._geo.startAngle
  }

  /**
   * Sets the start angle of this arc.
   *
   * @param value - The new start angle in radians (0 to 2π)
   *
   * @example
   * ```typescript
   * arc.startAngle = Math.PI / 4; // 45 degrees
   * ```
   */
  set startAngle(value: number) {
    this._geo.startAngle = value
  }

  /**
   * Gets the end angle of this arc.
   *
   * @returns The end angle in radians
   *
   * @example
   * ```typescript
   * const endAngle = arc.endAngle;
   * console.log(`Arc end angle: ${endAngle} radians (${endAngle * 180 / Math.PI} degrees)`);
   * ```
   */
  get endAngle(): number {
    return this._geo.endAngle
  }

  /**
   * Sets the end angle of this arc.
   *
   * @param value - The new end angle in radians (0 to 2π)
   *
   * @example
   * ```typescript
   * arc.endAngle = Math.PI; // 180 degrees
   * ```
   */
  set endAngle(value: number) {
    this._geo.endAngle = value
  }

  /**
   * Gets the arc's unit normal vector in WCS coordinates.
   *
   * @returns The arc's unit normal vector
   *
   * @example
   * ```typescript
   * const normal = arc.normal;
   * console.log(`Normal: ${normal.x}, ${normal.y}, ${normal.z}`);
   * ```
   */
  get normal(): AcGeVector3d {
    return this._geo.normal
  }

  /**
   * Sets the arc's unit normal vector in WCS coordinates.
   *
   * @param value - The new arc's unit normal vector
   *
   * @example
   * ```typescript
   * arc.normal = new AcGeVector3d(0, 0, 1);
   * ```
   */
  set normal(value: AcGeVector3dLike) {
    this.setNormalAndRefVec(value)
  }

  /**
   * Thickness along the entity normal (DXF group 39).
   */
  get thickness() {
    return this._thickness
  }
  set thickness(value: number) {
    this._thickness = value
  }

  /**
   * Gets the start point of this arc.
   *
   * The start point is calculated based on the center, radius, and start angle.
   *
   * @returns The start point as a 3D point
   *
   * @example
   * ```typescript
   * const startPoint = arc.startPoint;
   * console.log(`Arc start point: ${startPoint.x}, ${startPoint.y}, ${startPoint.z}`);
   * ```
   */
  get startPoint(): AcGePoint3d {
    return this._geo.startPoint
  }

  /**
   * Gets the end point of this arc.
   *
   * The end point is calculated based on the center, radius, and end angle.
   *
   * @returns The end point as a 3D point
   *
   * @example
   * ```typescript
   * const endPoint = arc.endPoint;
   * console.log(`Arc end point: ${endPoint.x}, ${endPoint.y}, ${endPoint.z}`);
   * ```
   */
  get endPoint(): AcGePoint3d {
    return this._geo.endPoint
  }

  /**
   * The middle point of the circular arc
   */
  get midPoint(): AcGePoint3d {
    return this._geo.midPoint
  }

  /**
   * Gets the geometric extents (bounding box) of this arc.
   *
   * @returns The bounding box that encompasses the entire arc
   *
   * @example
   * ```typescript
   * const extents = arc.geometricExtents;
   * console.log(`Arc bounds: ${extents.minPoint} to ${extents.maxPoint}`);
   * ```
   */
  get geometricExtents() {
    return this._geo.box
  }

  /** @inheritdoc */
  override subGetIntersectCurves(): AcGeIntersectPrimitive[] {
    return [
      {
        kind: 'circArc',
        arc: this._geo.clone(),
        extendable: !this.closed
      }
    ]
  }

  /**
   * Gets whether this arc is closed.
   *
   * An arc is considered closed if the start and end angles are the same
   * (forming a complete circle).
   *
   * @returns True if the arc is closed (forms a complete circle), false otherwise
   */
  get closed(): boolean {
    return this._geo.closed
  }

  /** @inheritdoc */
  get area(): number {
    return this._geo.area
  }

  /**
   * Returns the full property definition for this arc entity, including
   * general group and geometry group.
   *
   * The geometry group exposes editable properties via {@link AcDbPropertyAccessor}
   * so the property palette can update the arc in real-time.
   *
   * Each property is an {@link AcDbEntityRuntimeProperty}.
   */
  get properties(): AcDbEntityProperties {
    return {
      type: this.type,
      groups: [
        this.getGeneralProperties(),
        {
          groupName: 'geometry',
          properties: [
            // --- Cennter Point ---
            {
              name: 'centerX',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.center.x,
                set: (v: number) => {
                  this.center.x = v
                }
              }
            },
            {
              name: 'centerY',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.center.y,
                set: (v: number) => {
                  this.center.y = v
                }
              }
            },
            {
              name: 'centerZ',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.center.z,
                set: (v: number) => {
                  this.center.z = v
                }
              }
            },
            {
              name: 'radius',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.radius,
                set: (v: number) => {
                  this.radius = v
                }
              }
            },
            {
              name: 'startAngle',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.startAngle,
                set: (v: number) => {
                  this.startAngle = v
                }
              }
            },
            {
              name: 'endAngle',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.endAngle,
                set: (v: number) => {
                  this.endAngle = v
                }
              }
            },
            {
              name: 'normalX',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.normal.x,
                set: (v: number) => {
                  this.normal.x = v
                }
              }
            },
            {
              name: 'normalY',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.normal.y,
                set: (v: number) => {
                  this.normal.y = v
                }
              }
            },
            {
              name: 'normalZ',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.normal.z,
                set: (v: number) => {
                  this.normal.z = v
                }
              }
            },
            {
              name: 'arcLength',
              type: 'float',
              editable: false,
              accessor: {
                get: () => this._geo.length
              }
            },
            {
              name: 'totalAngle',
              type: 'float',
              editable: false,
              accessor: {
                get: () => AcGeMathUtil.radToDeg(Math.abs(this._geo.deltaAngle))
              }
            },
            {
              name: 'area',
              type: 'float',
              editable: false,
              accessor: {
                get: () => this.area
              }
            }
          ]
        }
      ]
    }
  }

  /**
   * Gets the grip points for this arc.
   *
   * Grip points are control points that can be used to modify the arc.
   * For an arc, the grip points are the center point, start point, and end point.
   *
   * @returns Array of grip points (center, start point, end point)
   *
   * @example
   * ```typescript
   * const gripPoints = arc.subGetGripPoints();
   * // gripPoints contains: [center, startPoint, endPoint]
   * ```
   */
  subGetGripPoints() {
    const gripPoints = new Array<AcGePoint3d>()
    gripPoints.push(this.center)
    gripPoints.push(this.startPoint)
    gripPoints.push(this.endPoint)
    return gripPoints
  }

  /** @inheritdoc */
  subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike) {
    acdbForEachGripIndex(indices, index => {
      this.moveGripAt(index, offset)
    })
    return this
  }

  /**
   * Gets the object snap points for this arc.
   *
   * Object snap points are precise points that can be used for positioning
   * when drawing or editing. This method provides snap points based on the
   * specified snap mode.
   *
   * @param osnapMode - The object snap mode
   * @param pickPoint - The point where the user picked
   * @param _lastPoint - The last point
   * @param snapPoints - Array to populate with snap points
   */
  subGetOsnapPoints(
    osnapMode: AcDbOsnapMode,
    pickPoint: AcGePoint3dLike,
    _lastPoint: AcGePoint3dLike,
    snapPoints: AcGePoint3dLike[]
  ) {
    const startPoint = this.startPoint
    const endPoint = this.endPoint

    switch (osnapMode) {
      case AcDbOsnapMode.EndPoint:
        snapPoints.push(startPoint)
        snapPoints.push(endPoint)
        break
      case AcDbOsnapMode.MidPoint:
        snapPoints.push(this.midPoint)
        break
      case AcDbOsnapMode.Center:
      case AcDbOsnapMode.Centroid:
        snapPoints.push(this._geo.center)
        break
      case AcDbOsnapMode.Quadrant: {
        const criticalAngles = [0, Math.PI / 2, Math.PI, (3 * Math.PI) / 2]
        for (const angle of criticalAngles) {
          if (
            AcGeMathUtil.isBetweenAngle(angle, this.startAngle, this.endAngle)
          ) {
            snapPoints.push(this._geo.getPointAtAngle(angle))
          }
        }
        break
      }
      case AcDbOsnapMode.Nearest:
        {
          const projectedPoint = this._geo.nearestPoint(pickPoint)
          snapPoints.push(projectedPoint)
        }
        break
      case AcDbOsnapMode.Perpendicular: {
        const candidates = this._geo.perpendicularPoints(pickPoint)
        const nearest = acdbPickNearestOsnapPoint(pickPoint, candidates)
        if (nearest) snapPoints.push(nearest)
        break
      }
      case AcDbOsnapMode.Tangent: {
        const points = this._geo.tangentPoints(pickPoint)
        snapPoints.push(...points)
        break
      }
      default:
        break
    }
  }

  /**
   * Transforms this arc by the specified matrix.
   *
   * This method applies a geometric transformation to the arc, updating
   * the center point, radius, and angles according to the transformation matrix.
   *
   * @param matrix - The transformation matrix to apply
   * @returns This arc after transformation
   *
   * @example
   * ```typescript
   * const translationMatrix = AcGeMatrix3d.translation(10, 0, 0);
   * arc.transformBy(translationMatrix);
   * // Arc is now translated 10 units in the X direction
   * ```
   */
  transformBy(matrix: AcGeMatrix3d) {
    this._geo.transform(matrix)
    return this
  }

  /**
   * This arc always draws as a single `lineStrip` primitive.
   *
   * @internal
   */
  override get directBatchPrimitive() {
    return 'lineStrip' as const
  }

  /**
   * Draws this arc using the specified renderer.
   *
   * This method renders the arc as a circular arc using the arc's
   * current style properties.
   *
   * @param renderer - The renderer to use for drawing
   * @returns The rendered arc entity, or undefined if drawing failed
   *
   * @example
   * ```typescript
   * const renderedArc = arc.draw(renderer);
   * ```
   */
  subWorldDraw(renderer: AcGiRenderer) {
    return renderer.circularArc(this._geo)
  }

  /**
   * Writes DXF fields for this object.
   *
   * @param filer - DXF output writer.
   * @returns The instance (for chaining).
   */
  override dxfOutFields(filer: AcDbDxfFiler) {
    super.dxfOutFields(filer)
    const centerOcs = acgeTransformWcsPointToOcs(this.center, this.normal)
    // AutoCAD ARC uses AcDbCircle (center/radius/normal) + AcDbArc (angles).
    filer.writeSubclassMarker('AcDbCircle')
    if (this.thickness !== 0) {
      filer.writeDouble(39, this.thickness)
    }
    filer.writePoint3d(10, centerOcs)
    filer.writeDouble(40, this.radius)
    filer.writeVector3d(210, this.normal)
    filer.writeSubclassMarker('AcDbArc')
    filer.writeAngle(50, acgeGetOcsAngle(this.center, this.startPoint, this.normal))
    filer.writeAngle(51, acgeGetOcsAngle(this.center, this.endPoint, this.normal))
    return this
  }

  override dxfInFields(filer: AcDbDxfFiler): this {
    super.dxfInFields(filer)

    let x = 0
    let y = 0
    let z = 0
    let radius = this.radius
    let startDeg = AcGeMathUtil.radToDeg(this.startAngle)
    let endDeg = AcGeMathUtil.radToDeg(this.endAngle)
    let nx = this.normal.x
    let ny = this.normal.y
    let nz = this.normal.z

    const readGeometryCodes = (
      stopOnNextSubclass: boolean
    ): boolean => {
      while (!filer.atEndOfObject && !filer.atEof && !filer.atExtendedData) {
        const item = filer.readItem()
        if (!item) break
        const code = Number(item.code)
        if (stopOnNextSubclass && code === 100) {
          filer.pushBackItem(item)
          return true
        }
        const n = Number(item.value)
        switch (code) {
          case 10:
            x = n
            break
          case 20:
            y = n
            break
          case 30:
            z = n
            break
          case 40:
            radius = n
            break
          case 39:
            this.thickness = n
            break
          case 50:
            startDeg = n
            break
          case 51:
            endDeg = n
            break
          case 210:
            nx = n
            break
          case 220:
            ny = n
            break
          case 230:
            nz = n
            break
          default:
            break
        }
      }
      return false
    }

    // Prefer AutoCAD layout: AcDbCircle then AcDbArc. Also accept AcDbArc-only
    // (legacy writers that inlined center/radius under AcDbArc).
    if (filer.atSubclassData('AcDbCircle')) {
      readGeometryCodes(true)
    }
    if (filer.atSubclassData('AcDbArc')) {
      readGeometryCodes(false)
    } else if (!filer.peekItem() || Number(filer.peekItem()?.code) !== 100) {
      // No subclass markers left — consume remaining geometry codes if present.
      readGeometryCodes(false)
    }

    this.applyDxfInGeometry(x, y, z, radius, startDeg, endDeg, nx, ny, nz)
    return this
  }

  private applyDxfInGeometry(
    x: number,
    y: number,
    z: number,
    radius: number,
    startDeg: number,
    endDeg: number,
    nx: number,
    ny: number,
    nz: number
  ) {
    _dxfInNormal.set(nx, ny, nz)
    if (_dxfInNormal.lengthSq() > 0) {
      _dxfInNormal.normalize()
    }
    // DXF arcs are created with a default +Z normal/refVec, then filled via
    // dxfIn. Sync refVec with the OCS X axis or -Z extrusions tessellate on
    // the mirrored side of the center (messy chords for large-radius fillets).
    acgeGetOcsReferenceVectorInto(_dxfInRefVec, _dxfInNormal)
    acgeTransformOcsPointToWcsInto(_dxfInPoint, { x, y, z }, _dxfInNormal)
    // Build the final geometry in one pass; the entity's default geometry is
    // never materialized (see the lazy _geo accessor).
    this._geo = new AcGeCircArc3d(
      _dxfInPoint,
      radius,
      AcGeMathUtil.degToRad(startDeg),
      AcGeMathUtil.degToRad(endDeg),
      _dxfInNormal,
      _dxfInRefVec
    )
  }

  private setNormalAndRefVec(normal: AcGeVector3dLike) {
    this._geo.normal = normal
    acgeGetOcsReferenceVectorInto(_dxfInRefVec, this._geo.normal)
    this._geo.refVec = _dxfInRefVec
  }

  override getOffsetCurves(offsetDist: number): AcDbCurve[] {
    const curve = this.createOffsetCurve(offsetDist)
    return curve ? [curve] : []
  }

  override getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1 {
    const c = this.center
    const r = this.radius
    return Math.sqrt((point.x - c.x) ** 2 + (point.y - c.y) ** 2) >= r ? 1 : -1
  }

  private moveGripAt(gripIndex: number, offset: AcGeVector3dLike) {
    switch (gripIndex) {
      case 0:
        this.transformBy(AcGeMatrix3d.makeTranslation(offset))
        break
      case 1: {
        const point = this._geo.startPoint
        this._geo.startAngle = acgeGetOcsAngle(
          this._geo.center,
          {
            x: point.x + offset.x,
            y: point.y + offset.y,
            z: (point.z ?? 0) + (offset.z ?? 0)
          },
          this._geo.normal
        )
        break
      }
      case 2: {
        const point = this._geo.endPoint
        this._geo.endAngle = acgeGetOcsAngle(
          this._geo.center,
          {
            x: point.x + offset.x,
            y: point.y + offset.y,
            z: (point.z ?? 0) + (offset.z ?? 0)
          },
          this._geo.normal
        )
        break
      }
      default:
        break
    }
  }

  private createOffsetCurve(offsetDist: number): AcDbArc | null {
    const geo = this._geo.offset(offsetDist)
    if (!geo) return null
    return new AcDbArc(
      geo.center,
      geo.radius,
      geo.startAngle,
      geo.endAngle,
      geo.normal
    )
  }
}

